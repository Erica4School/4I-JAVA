// voglio premere il tasto spazio da tastiera 
// il mio consumatore deve aspettare --> wait()
public class App {

	public static void main(String[] args) throws InterruptedException {
		final Processor processor = new Processor();
		Thread t1 = new Thread (new Runnable() {

			@Override
			public void run() {
				try {
				// produce	
				processor.produce();	
				}
				catch(InterruptedException e) {}
			}	
			});
			
		Thread t2 = new Thread (new Runnable() {

			@Override
			public void run() {
				try {
				//consumare	
					processor.consume();	
				}
				catch(InterruptedException e) {}
			}	
			});
		
		t1.start();
		t2.start();
		
		t1.join();
		t2.join();
		}

	}


