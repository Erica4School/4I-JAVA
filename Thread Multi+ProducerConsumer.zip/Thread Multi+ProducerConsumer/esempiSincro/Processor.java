import java.util.Scanner;

//metodi relativi al consumo e alla produzione
public class Processor {
public void consume() throws InterruptedException {
	System.out.println("consumer dice helleu");
	synchronized(this){
	System.out.println("consumer thread è in stato di run");
	wait(); // time out infinto --> lui aspetta che il producer rilasci la risorsa
//in questo modo è resource efficient perchè non consuma risorse visto che è in attesa
//una volta che ho chiamato wait, si blocca e solo successivamente posso dargli il controllo della risorsa, 
//ma in un primo step risulta bloccato finche io non lo richiamo ovvero finche la risorsa non viene liberata
			
	System.out.println("la risorsa è ora del consumer");
	
	}


// produttore

	
}

public void produce() throws InterruptedException {
	//prendere i tasti da tastiera
			Scanner scanner =new Scanner (System.in);
			Thread.sleep(2000);
//l'ho messo a dormire quindi è sicuramente il primo thread a partire è quello del consumatore
		//questo parte dopo che ha finito lo sleep
			synchronized(this){
				System.out.println("premi il tasto invio da tastiera");
				scanner.nextLine();
				System.out.println("tasto invio è premuto");
				//notify si puo usare solo con synchronzied
			notify(); //sto notificando che mi risveglio dal mio sonno e ti notifico che ora sono nello stato di ready 
			//intanto il primo thread è ancora nello stato di wait
			//prendo il controllo dell oggeto ovvero della tastiera
			//una volta chiamato il notify esce dal blocco synchrionized e libera la risorsa
			//adesso può essere usato dal thread precedente che esce dalla stato di wait
			Thread.sleep(5000);
			
			//notify non è sufficiente e per cui devo finire facendolo dormire per far passare l'oggetto 
	
	
}
}}
