import javax.sound.sampled.*;
import javax.swing.*;
import java.awt.*;
import java.io.File;
import java.io.IOException;

public class MusicPlayer extends JPanel {
    private boolean isPlaying = false;
    private Clip clip;

    public MusicPlayer() {
        setPreferredSize(new Dimension(200, 100));
        JButton playButton = new JButton("Play");
        playButton.addActionListener(e -> playMusic());
        add(playButton);

        JButton stopButton = new JButton("Stop");
        stopButton.addActionListener(e -> stopMusic());
        add(stopButton);
    }

    private synchronized void playMusic() {
        if (!isPlaying) {
            try {
                File musicFile = new File("src/guitar.wav");
                AudioInputStream audioStream = AudioSystem.getAudioInputStream(musicFile);
                clip = AudioSystem.getClip();
                clip.open(audioStream);
                clip.start();
                isPlaying = true;
            } catch (LineUnavailableException | IOException | UnsupportedAudioFileException ex) {
                ex.printStackTrace();
            }
        }
    }

    private synchronized void stopMusic() {
        if (isPlaying && clip != null) {
            clip.stop();
            isPlaying = false;
        }
    }

    public static void main(String[] args) {
        
            JFrame frame = new JFrame("Music Player");
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.getContentPane().add(new MusicPlayer());
            frame.pack();
            frame.setVisible(true);
    
    
    }}

