//https://youtu.be/jkRN9zcLH1s?feature=shared
public class Multi implements Runnable{
	
	int num;
	Multi(int num){
	this.num=num;	
	}
	@Override
	public void run() {
	for(int i=1; i<=5; i++) {
		System.out.println(i+ "thread "+num);
	}	
	}
	 public static void main(String[] args) throws InterruptedException {
for (int i=0; i<=3; i++) {
	 Multi a = new Multi(i);
	 Thread b = new Thread(a);
	 b.start();
	// b.join();
	 }

	
}}
